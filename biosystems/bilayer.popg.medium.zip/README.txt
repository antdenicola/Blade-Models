Blade Models for OCCAM MD Code
topology for: DPPC phospholipid
-----------------------------------------
Contact: adenicola.chem@gmail.com

Reference(s):
-------------

-Model-
Kolli, H. B.; De Nicola, A.; Bore, S. L.; Schäfer, K.; Diezemann, G.; Gauss, J.; Kawakatsu, T.; Lu, Z.; Zhu, Y.-L. Y.; Milano, G.; Cascella M. 
Hybrid Particle-Field Molecular Dynamics Simulations of Charged Amphiphiles in an Aqueous Environment. 
J. Chem. Theory Comput. 2018, 14 (9), 4928–4937. 
https://doi.org/10.1021/acs.jctc.8b00466.

-Occam Code-
Zhao, Y.; De Nicola, A.; Kawakatsu, T.; Milano, G. 
Hybrid Particle-Field Molecular Dynamics Simulations: Parallelization and Benchmarks. 
J. Comput. Chem. 2012, 33 (8), 868–880. 
https://doi.org/10.1002/jcc.22883.
WEB: www.occammd.org

Package Conent:
fort.1 (simulation settings)
fort.3 (model parameters)
fort.5 (coordinate set)
dppc.pdb (single molecule)
con.occ (connectivity list)
comp.dat (composition system)
