Blade Models for OCCAM MD Code
topology for: Pluronic L64   
-----------------------------------------
Created by Antonio De Nicola 2013.02.02
Contact: adenicola.chem@gmail.com

Reference(s):
-------------

-Model-
De Nicola, A.; Kawakatsu, T.; Milano, G. 
A Hybrid Particle-Field Coarse-Grained Molecular Model for Pluronics Water Mixtures. Macromol. 
Chem. Phys. 2013, 214 (17), 1940–1950. 
https://doi.org/10.1002/macp.201300214.

-Occam Code-
Zhao, Y.; De Nicola, A.; Kawakatsu, T.; Milano, G. 
Hybrid Particle-Field Molecular Dynamics Simulations: Parallelization and Benchmarks. 
J. Comput. Chem. 2012, 33 (8), 868–880. 
https://doi.org/10.1002/jcc.22883.
WEB: www.occammd.org

Package Conent:
fort.1 (simulation settings)
fort.3 (model parameters)
fort.5 (coordinate set)
l64.pdb (system 650 L64 chains)
con.occ (connectivity list)
comp.dat (composition system)
