Blade Models for OCCAM MD Code
topology for: DPPC phospholipid
-----------------------------------------
Created by Antonio De Nicola 2011.08.03
Contact: adenicola.chem@gmail.com

Reference(s):
-------------

-Model-
De Nicola, A.; Zhao, Y.; Kawakatsu, T.; Roccatano, D.; Milano, G. 
Hybrid Particle-Field Coarse-Grained Models for Biological Phospholipids. 
J. Chem. Theory Comput. 2011, 7 (9), 2947–2962. 
https://doi.org/10.1021/ct200132n.

-Occam Code-
Zhao, Y.; De Nicola, A.; Kawakatsu, T.; Milano, G. 
Hybrid Particle-Field Molecular Dynamics Simulations: Parallelization and Benchmarks. 
J. Comput. Chem. 2012, 33 (8), 868–880. 
https://doi.org/10.1002/jcc.22883.
WEB: www.occammd.org

Package Conent:
fort.1 (simulation settings)
fort.3 (model parameters)
fort.5 (coordinate set)
dppc.pdb (single molecule)
con.occ (connectivity list)
comp.dat (composition system)
