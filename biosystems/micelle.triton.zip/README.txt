Blade Models for OCCAM MD Code
topology for: Triton X100. PEG units n=9, n=10
-----------------------------------------
Created by Antonio De Nicola 2015.08.18
Contact: adenicola.chem@gmail.com

Reference(s):
-------------

-Model-
De Nicola, A.; Kawakatsu, T.; Rosano, C.; Celino, M.; Rocco, M.; Milano, G. 
Self-Assembly of Triton X-100 in Water Solutions: A Multiscale Simulation Study Linking Mesoscale to Atomistic Models. 
J. Chem. Theory Comput. 2015, 11 (10), 4959–4971. 
https://doi.org/10.1021/acs.jctc.5b00485.


-Occam Code-
Zhao, Y.; De Nicola, A.; Kawakatsu, T.; Milano, G. 
Hybrid Particle-Field Molecular Dynamics Simulations: Parallelization and Benchmarks. 
J. Comput. Chem. 2012, 33 (8), 868–880. 
https://doi.org/10.1002/jcc.22883.
WEB: www.occammd.org

Package Conent:
fort.1 (simulation settings)
fort.3 (model parameters)
fort.5 (coordinate set)
tx10.pdb (single molecule, n=10)
tx09.pdb (single molecule, n=9)
con.occ (connectivity list)
comp.dat (composition if the system)
